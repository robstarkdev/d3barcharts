from WhoIsHostingThis.com

More info: whoishostingthis.com/resources/flag-icons/